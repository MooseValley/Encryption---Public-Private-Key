# Encryption - Public, Private Key

Anything encrypted with the public key can be decrypted with the private key.
The reverse is also true: anything encrypted using the private key can be
decrypted using the public key.

Tinkering, exploring, ....

**Moose OMalley**
<br>Moose's Software Valley - Established 29-Jul-1996
<br>https://moosevalley.github.io/

